# Nonlinear Spiral Animation with Music

This MATLAB script visualizes a nonlinear time-varying system as a 3D spiral in phase space, accompanied by background music.

## Features
- Nonlinear dynamics: Includes damping and forcing.
- 3D phase portrait with rotation support.
- Keyboard and button controls (Pause/Resume/Restart).
- Background music synced with animation.

## Usage
1. Open MATLAB.
2. Place `nonlinear_spiral_animation_with_music.m` and `bgmusic.wav` in the same folder.
3. Run the script.

Controls:
- Press `Space` to pause/resume.
- Press `R` or click `Restart` to reset.
- Press `Escape` or click `Close` to quit.
