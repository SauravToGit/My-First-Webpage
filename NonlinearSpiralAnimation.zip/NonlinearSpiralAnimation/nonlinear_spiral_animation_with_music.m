function nonlinear_spiral_animation_with_music()
    % Parameters
    k = 0.5;
    tspan = [0 50];
    y0 = [0.1; 0];  % Initial condition

    % Load music
    [bgY, Fs] = audioread('bgmusic.wav');

    % Create Figure
    fig = figure('Name', 'Nonlinear Spiral Animation', ...
        'KeyPressFcn', @keyHandler, ...
        'UserData', struct('paused', false, 'restart', false));

    ax = axes(fig);
    grid on;
    xlabel('y'); ylabel('dy/dt'); zlabel('t');
    view(3); rotate3d on;
    hold on;
    trail = animatedline('Color', [0.1 0.6 0.8], 'LineWidth', 1.5);
    dot = plot3(NaN, NaN, NaN, 'ro', 'MarkerSize', 6, 'MarkerFaceColor', 'r');

    % Display Equation
    eqnText = text(ax, 0.5, 0.5, 45, ...
        '$$\ddot{y} = \sin(t)\sin(y) - k\dot{y}^3 + \cos(2t)$$', ...
        'Interpreter', 'latex', 'FontSize', 14, 'Color', 'k');

    % GUI Buttons
    uicontrol('Style', 'pushbutton', 'String', 'Pause/Resume', ...
        'Position', [20 20 100 30], 'Callback', @(src, event)togglePause());
    uicontrol('Style', 'pushbutton', 'String', 'Restart', ...
        'Position', [140 20 100 30], 'Callback', @(src, event)setRestart());
    uicontrol('Style', 'pushbutton', 'String', 'Close', ...
        'Position', [260 20 100 30], 'Callback', @(src, event)close(fig));

    while ishandle(fig)
        % Solve ODE
        ode = @(t, y) [y(2); sin(t)*sin(y(1)) - k*y(2)^3 + cos(2*t)];
        [t, Y] = ode45(ode, tspan, y0);

        % Restart music
        player = audioplayer(bgY, Fs);
        play(player);

        % Animate
        N = length(t);
        i = 1;
        clearpoints(trail);
        while i <= N && ishandle(fig)
            state = get(fig, 'UserData');
            if state.restart
                set(fig, 'UserData', struct('paused', false, 'restart', false));
                break;  % exit to restart outer while loop
            elseif ~state.paused
                y = Y(i, 1); v = Y(i, 2); z = t(i);
                addpoints(trail, y, v, z);
                set(dot, 'XData', y, 'YData', v, 'ZData', z);
                drawnow;
                pause(0.03);
                i = i + 1;
            else
                pause(0.1);
            end
        end
    end

    % --- Callback Functions ---
    function keyHandler(~, event)
        state = get(fig, 'UserData');
        switch event.Key
            case 'space'
                state.paused = ~state.paused;
            case 'r'
                state.restart = true;
            case 'escape'
                close(fig);
        end
        set(fig, 'UserData', state);
    end

    function togglePause()
        state = get(fig, 'UserData');
        state.paused = ~state.paused;
        set(fig, 'UserData', state);
    end

    function setRestart()
        state = get(fig, 'UserData');
        state.restart = true;
        set(fig, 'UserData', state);
    end
end



